"""nb2py: dumps marked code cells from a Jupyter notebook into a text file."""

__author__ = "Hugo Guillen-Ramirez"
__copyright__ = "Copyright 2017"
__email__ = "hugoagr@gmail.com"

from .nb2py import dump,dump_indices

